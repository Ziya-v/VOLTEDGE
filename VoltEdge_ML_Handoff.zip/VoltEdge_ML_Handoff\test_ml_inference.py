import pandas as pd

from ml_inference import run_ml_pipeline


# ============================================================
# LOAD HISTORICAL DATA
# ============================================================

print("Loading training data...")

df = pd.read_parquet("voltedge_training_full.parquet")

print("Total rows:", len(df))
print("Total assets:", df["AssetId"].nunique())


# ============================================================
# SELECT ONE ASSET
# ============================================================

asset_id = "ahu_a"

asset_data = (
    df[df["AssetId"] == asset_id]
    .sort_values("window_start_utc")
    .tail(200)
    .copy()
)

print("\nTesting asset:", asset_id)
print("Rows used:", len(asset_data))


# ============================================================
# RUN ML PIPELINE
# ============================================================

print("\nRunning ML inference...")

result = run_ml_pipeline(asset_data)


# ============================================================
# DISPLAY RESULTS
# ============================================================

columns_to_show = [
    "AssetId",
    "window_start_utc",
    "Energy_kWh_15m",
    "expected_energy_kwh",
    "anomaly_flag",
    "anomaly_score",
    "severity",
    "excess_energy_kwh",
    "potential_waste_kwh",
    "potential_cost_impact"
]

available_columns = [
    column
    for column in columns_to_show
    if column in result.columns
]

print("\nRESULTS")
print("=" * 80)

print(
    result[available_columns].tail(20).to_string(
        index=False
    )
)


# ============================================================
# SUMMARY
# ============================================================

print("\n")
print("=" * 80)
print("ML INFERENCE SUMMARY")
print("=" * 80)

print(
    "Observations:",
    len(result)
)

print(
    "Anomalies:",
    int(
        result["anomaly_flag"]
        .fillna(0)
        .sum()
    )
)

print(
    "Potential waste (kWh):",
    round(
        result["potential_waste_kwh"]
        .sum(),
        2
    )
)

print(
    "Potential cost impact (₹):",
    round(
        result["potential_cost_impact"]
        .sum(),
        2
    )
)


# ============================================================
# SAVE TEST OUTPUT
# ============================================================

result.to_csv(
    "ml_inference_test_output.csv",
    index=False
)

print("\nTest output saved to:")
print("ml_inference_test_output.csv")