import pandas as pd

from ml_inference import run_ml_pipeline


# ============================================================
# VOLTEDGE MULTI-ASSET ML VALIDATION
# ============================================================

print("=" * 70)
print("VOLTEDGE MULTI-ASSET ML VALIDATION")
print("=" * 70)


# ============================================================
# LOAD DATA
# ============================================================

print("\nLoading dataset...")

df = pd.read_parquet(
    "voltedge_training_full.parquet"
)

print("Total rows:", len(df))
print("Total assets:", df["AssetId"].nunique())


# ============================================================
# SELECT ASSETS
# ============================================================

assets = [
    "ahu_a",
    "comp_a",
    "ex_a",
    "hp_a",
    "mi_a",
    "mix_a",
    "p_a",
    "sb_a",
    "u_a"
]


# ============================================================
# VALIDATE ASSETS
# ============================================================

all_results = []

for asset_id in assets:

    print("\n" + "-" * 70)
    print("Testing asset:", asset_id)
    print("-" * 70)

    asset_data = (
        df[df["AssetId"] == asset_id]
        .sort_values("window_start_utc")
        .tail(200)
        .copy()
    )

    if len(asset_data) == 0:

        print(
            "WARNING: Asset not found:",
            asset_id
        )

        continue

    print(
        "Rows used:",
        len(asset_data)
    )

    try:

        result = run_ml_pipeline(
            asset_data
        )

        valid_predictions = (
            result["expected_energy_kwh"]
            .notna()
            .sum()
        )

        anomalies = (
            result["anomaly_flag"]
            .fillna(0)
            .sum()
        )

        potential_waste = (
            result["potential_waste_kwh"]
            .fillna(0)
            .sum()
        )

        potential_cost = (
            result["potential_cost_impact"]
            .fillna(0)
            .sum()
        )

        print(
            "Valid predictions:",
            valid_predictions
        )

        print(
            "Anomalies:",
            int(anomalies)
        )

        print(
            "Potential waste:",
            round(
                potential_waste,
                3
            ),
            "kWh"
        )

        print(
            "Potential cost impact:",
            round(
                potential_cost,
                2
            ),
            "₹"
        )

        # ----------------------------------------------------
        # Store summary
        # ----------------------------------------------------

        all_results.append(
            {
                "AssetId": asset_id,
                "Rows": len(asset_data),
                "Valid_Predictions": int(
                    valid_predictions
                ),
                "Anomalies": int(
                    anomalies
                ),
                "Anomaly_Rate_%": round(
                    (
                        anomalies
                        / len(asset_data)
                    ) * 100,
                    2
                ),
                "Potential_Waste_kWh": round(
                    potential_waste,
                    3
                ),
                "Potential_Cost_Rupees": round(
                    potential_cost,
                    2
                )
            }
        )

    except Exception as error:

        print(
            "ERROR while testing",
            asset_id
        )

        print(
            error
        )


# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n")
print("=" * 70)
print("FINAL MULTI-ASSET VALIDATION")
print("=" * 70)


if all_results:

    summary = pd.DataFrame(
        all_results
    )

    print(
        summary.to_string(
            index=False
        )
    )

    print("\n" + "-" * 70)

    print(
        "Assets successfully tested:",
        len(summary)
    )

    print(
        "Total observations tested:",
        summary["Rows"].sum()
    )

    print(
        "Total valid predictions:",
        summary["Valid_Predictions"].sum()
    )

    print(
        "Total anomalies detected:",
        summary["Anomalies"].sum()
    )

    print(
        "Total potential waste:",
        round(
            summary[
                "Potential_Waste_kWh"
            ].sum(),
            3
        ),
        "kWh"
    )

    print(
        "Total potential cost impact:",
        round(
            summary[
                "Potential_Cost_Rupees"
            ].sum(),
            2
        ),
        "₹"
    )

    # --------------------------------------------------------
    # Save validation results
    # --------------------------------------------------------

    summary.to_csv(
        "voltedge_ml_validation.csv",
        index=False
    )

    print("\nValidation results saved to:")

    print(
        "voltedge_ml_validation.csv"
    )

else:

    print(
        "No assets were successfully tested."
    )


print("\n")
print("=" * 70)
print("VALIDATION COMPLETE")
print("=" * 70)