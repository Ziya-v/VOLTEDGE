import pandas as pd

from ml_inference import run_ml_pipeline


# ============================================================
# VOLTEDGE BACKEND → ML INTEGRATION EXAMPLE
# ============================================================

# In the real system, this data will come from the backend.
#
# For this example, we use historical data to simulate
# backend-provided energy data.

data = pd.read_parquet(
    "voltedge_training_full.parquet"
)


# ------------------------------------------------------------
# Example asset
# ------------------------------------------------------------

asset_id = "ahu_a"


asset_data = (
    data[data["AssetId"] == asset_id]
    .sort_values("window_start_utc")
    .tail(200)
    .copy()
)


# ------------------------------------------------------------
# Call the VoltEdge ML module
# ------------------------------------------------------------

result = run_ml_pipeline(
    asset_data
)


# ------------------------------------------------------------
# Get the latest valid ML result
# ------------------------------------------------------------

result = result[
    result["expected_energy_kwh"].notna()
].copy()


latest = result.iloc[-1]


# ------------------------------------------------------------
# Backend-ready response
# ------------------------------------------------------------

response = {
    "asset_id": latest["AssetId"],
    "timestamp": str(
        latest["window_start_utc"]
    ),

    "actual_energy_kwh": float(
        latest["Energy_kWh_15m"]
    ),

    "expected_energy_kwh": float(
        latest["expected_energy_kwh"]
    ),

    "anomaly": bool(
        latest["anomaly_flag"] == 1
    ),

    "anomaly_score": float(
        latest["anomaly_score"]
    )
    if pd.notna(
        latest["anomaly_score"]
    )
    else None,

    "severity": str(
        latest["severity"]
    ),

    "potential_excess_energy_kwh": float(
        latest["excess_energy_kwh"]
    )
    if pd.notna(
        latest["excess_energy_kwh"]
    )
    else None,

    "potential_waste_kwh": float(
        latest["potential_waste_kwh"]
    )
    if pd.notna(
        latest["potential_waste_kwh"]
    )
    else None,

    "potential_cost_impact_rupees": float(
        latest["potential_cost_impact"]
    )
    if pd.notna(
        latest["potential_cost_impact"]
    )
    else None
}


# ------------------------------------------------------------
# Display response
# ------------------------------------------------------------

print()
print("=" * 70)
print("BACKEND → VOLTEDGE ML RESPONSE")
print("=" * 70)

for key, value in response.items():

    print(
        f"{key}: {value}"
    )

print()
print("=" * 70)
print("INTEGRATION TEST COMPLETE")
print("=" * 70)