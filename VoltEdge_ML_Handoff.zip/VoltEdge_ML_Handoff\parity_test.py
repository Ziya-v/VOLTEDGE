import pandas as pd

from ml_inference import detect_anomalies


print("=" * 70)
print("VOLTEDGE MODEL PARITY TEST")
print("=" * 70)


# ------------------------------------------------------------
# Load original results
# ------------------------------------------------------------

print("\nLoading original anomaly results...")

original = pd.read_csv(
    "voltedge_anomaly_results.csv"
)

original["window_start_utc"] = pd.to_datetime(
    original["window_start_utc"],
    errors="coerce"
)


# ------------------------------------------------------------
# Load original training data
# ------------------------------------------------------------

print("Loading training data...")

df = pd.read_parquet(
    "voltedge_training_full.parquet"
)

df["window_start_utc"] = pd.to_datetime(
    df["window_start_utc"],
    errors="coerce"
)


# ------------------------------------------------------------
# Select hp_a last 200 observations
# ------------------------------------------------------------

asset_id = "hp_a"

asset_data = (
    df[df["AssetId"] == asset_id]
    .sort_values("window_start_utc")
    .tail(200)
    .copy()
)

print("\nAsset:", asset_id)
print("Rows:", len(asset_data))


# ------------------------------------------------------------
# Run new inference
# ------------------------------------------------------------

print("\nRunning new inference...")

new_result = detect_anomalies(
    asset_data
)


# ------------------------------------------------------------
# Select comparison columns
# ------------------------------------------------------------

new_result = new_result[
    [
        "AssetId",
        "window_start_utc",
        "anomaly_flag"
    ]
].copy()

original_subset = original[
    original["AssetId"] == asset_id
][
    [
        "AssetId",
        "window_start_utc",
        "anomaly_flag"
    ]
].copy()


# ------------------------------------------------------------
# Keep only timestamps from our test period
# ------------------------------------------------------------

test_timestamps = set(
    asset_data["window_start_utc"]
)

original_subset = original_subset[
    original_subset["window_start_utc"]
    .isin(test_timestamps)
].copy()


# ------------------------------------------------------------
# Rename columns
# ------------------------------------------------------------

new_result = new_result.rename(
    columns={
        "anomaly_flag":
        "new_anomaly_flag"
    }
)

original_subset = original_subset.rename(
    columns={
        "anomaly_flag":
        "original_anomaly_flag"
    }
)


# ------------------------------------------------------------
# Merge
# ------------------------------------------------------------

comparison = pd.merge(
    original_subset,
    new_result,
    on=[
        "AssetId",
        "window_start_utc"
    ],
    how="inner"
)


# ------------------------------------------------------------
# Compare only valid new predictions
# ------------------------------------------------------------

comparison = comparison[
    comparison["new_anomaly_flag"]
    .notna()
].copy()


comparison["match"] = (
    comparison["original_anomaly_flag"]
    ==
    comparison["new_anomaly_flag"]
)


# ------------------------------------------------------------
# Results
# ------------------------------------------------------------

total_compared = len(comparison)

matches = int(
    comparison["match"].sum()
)

mismatches = (
    total_compared - matches
)


print("\n")
print("=" * 70)
print("PARITY RESULTS")
print("=" * 70)

print(
    "Rows compared:",
    total_compared
)

print(
    "Matching anomaly flags:",
    matches
)

print(
    "Mismatching anomaly flags:",
    mismatches
)

if total_compared > 0:

    accuracy = (
        matches
        / total_compared
    ) * 100

    print(
        "Parity:",
        round(accuracy, 2),
        "%"
    )


# ------------------------------------------------------------
# Show mismatches
# ------------------------------------------------------------

if mismatches > 0:

    print("\n")
    print("=" * 70)
    print("MISMATCHED ROWS")
    print("=" * 70)

    print(
        comparison[
            ~comparison["match"]
        ].to_string(
            index=False
        )
    )

else:

    print("\n")
    print(
        "SUCCESS: New inference reproduces "
        "the original anomaly flags."
    )


# ------------------------------------------------------------
# Save comparison
# ------------------------------------------------------------

comparison.to_csv(
    "voltedge_parity_test.csv",
    index=False
)

print("\nComparison saved to:")
print("voltedge_parity_test.csv")

print("\n")
print("=" * 70)
print("PARITY TEST COMPLETE")
print("=" * 70)