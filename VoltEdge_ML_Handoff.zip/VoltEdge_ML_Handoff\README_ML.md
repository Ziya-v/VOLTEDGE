# VoltEdge ML Module

## 1. Overview

The VoltEdge ML module analyzes industrial energy consumption and provides:

- Expected energy consumption
- Energy anomaly detection
- Anomaly score
- Anomaly severity
- Potential excess energy
- Potential cost impact

The module is designed to be integrated with the backend and frontend of the VoltEdge system.

---

## 2. ML Models

### Energy Model

File:

`voltedge_energy_model_full.pkl`

The saved package contains:

- Trained energy prediction model
- Required feature list
- Numeric feature information
- Asset feature information

### Anomaly Models

File:

`voltedge_anomaly_models.pkl`

The file contains asset-specific Isolation Forest models.

Number of trained asset models:

`37`

Each asset model contains:

- Isolation Forest model
- StandardScaler
- Required anomaly features

---

## 3. ML Features

The anomaly detection model uses:

- Energy_kWh_15m
- lag_1
- lag_2
- lag_4
- lag_8
- lag_96
- energy_change
- energy_change_pct
- daily_change
- daily_change_pct
- hour_sin
- hour_cos
- day_sin
- day_cos

The energy model additionally uses time features and asset-specific encoded features.

---

## 4. Main ML Interface

The main integration file is:

`ml_inference.py`

The main function is:

```python
run_ml_pipeline(data)